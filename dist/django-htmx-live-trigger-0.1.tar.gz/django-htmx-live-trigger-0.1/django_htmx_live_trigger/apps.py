from django.apps import AppConfig


class LiveappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'django_htmx_live_trigger'
    label = 'django_htmx_live_trigger'
